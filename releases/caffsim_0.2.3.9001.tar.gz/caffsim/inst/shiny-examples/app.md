### Apps by AMC CPT

#### Vancomycin TDM KR
<img src=http://i.imgur.com/M8R3Me8.png width = 500 />

- <https://asan.shinyapps.io/vtdm>
- 2016-12 

#### Caffeine Concentration Predictor
<img src=http://i.imgur.com/RYJHxNq.png width = 500 />

- <https://asan.shinyapps.io/caff>
- 2016-12

#### Online NonCompart
<img src=http://i.imgur.com/k6VqHp2.png width = 500 />

- <https://asan.shinyapps.io/noncompart>
- 2016-11 
