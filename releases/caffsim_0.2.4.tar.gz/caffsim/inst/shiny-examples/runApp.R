# runApp ----

shiny::runApp('inst/shiny-examples', port = 8080, launch.browser = TRUE)
# shiny::runApp('inst/shiny-examples', port = 1080, launch.browser = TRUE) # for a local test 

