caffsim 0.2.2
===========

* Introduce a `shiny` example - `Caffeine Concentration Predictor`
* Add several functions - 

caffsim 0.2.0
===========

* Initial CRAN release


caffsim 0.1.0
===========

* Initial private beta release!
