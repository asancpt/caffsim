### Contact

- `Caffeine Concentration Predictor` Shiny developer: Sungpil Han <shan@acp.kr> / <https://shanmdphd.github.io>
- Acknowledgements : The main idea and intellectual resources were mainly provided by Professor Kyun-Seop Bae <k@acr.kr>.
- Copyright: 2016, Sungpil Han
- License: GPL-3
