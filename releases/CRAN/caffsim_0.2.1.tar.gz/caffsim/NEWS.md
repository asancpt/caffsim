caffsim 0.2.1
===========

* Introduce a `shiny` example - `Caffeine Concentration Predictor`


caffsim 0.2.0
===========

* Initial CRAN release


caffsim 0.1.0
===========

* Initial private beta release!
