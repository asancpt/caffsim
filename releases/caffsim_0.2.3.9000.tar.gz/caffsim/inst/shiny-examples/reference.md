**Reference range**

- Below 10 mg/L: generally considered safe (Green horizontal line)
- Over 40 mg/L: several fatalities (Blue horizontal line)
- Over 80 mg/L: fatal caffeine poisoning (Red horizontal line)
- Reference: de Wijkerslooth LR et al.(2008), Seifert et al.(2013), Banerjee et al. (2014), Cannon et al. (2001)
